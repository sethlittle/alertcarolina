package comp110;

/*
 * Author: Seth Little
 *
 * ONYEN: sethl
 *
 * UNC Honor Pledge: I certify that no unauthorized assistance has been 
 * received or given in the completion of this work. I collaborated with
 * no one other than official COMP110 UTAs on this code.
 */
public class AlertCarolinaCalculator {

	public static void main(String[] args) {

		Console console = new Console("Alert CAROLina Calculator");

		// TODO: Calculate Alert Carolina Score

		double temperatureInF = console.promptDouble("Temperature in Fahrenheit");
		double temperatureInC = (((temperatureInF - 32) * 5) / 9);

		double inchesSnowFallen = console.promptDouble("Inches of snow fallen");
		double cmSnowFallen = inchesSnowFallen * 2.54;

		double inchesSnowProj = console.promptDouble("Inches of snow projected");
		double cmSnowProj = inchesSnowProj * 2.54;

		double TotalSnow = cmSnowFallen + cmSnowProj;
		double AlertCarolinaRiskScore = (-1.0 * temperatureInC) + (5.0 * TotalSnow);

		String firstMessage = "Temperature (C): " + temperatureInC;
		console.print(firstMessage);

		String secondMessage = "Total Snow (cm): " + TotalSnow;
		console.print(secondMessage);

		String thirdMessage = "Alert Carolina Risk Score: " + AlertCarolinaRiskScore;
		console.print(thirdMessage);

	}

}