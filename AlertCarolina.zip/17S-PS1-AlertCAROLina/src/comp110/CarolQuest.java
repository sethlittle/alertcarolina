package comp110;

/*
 * Author: Seth Little
 *
 * ONYEN: sethl
 *
 * UNC Honor Pledge: I certify that no unauthorized assistance has been 
 * received or given in the completion of this work. I collaborated with
 * no one other than official COMP110 UTAs on this code.
 */
public class CarolQuest {

	public static void main(String[] args) {

		Chancellor carol = new Chancellor("sethl");

		carol.moveForward(8);
		carol.turnLeft(90);
		carol.moveForward(5);
		carol.turnRight(90);
		carol.moveForward(34);
		carol.turnLeft(90);
		carol.moveForward(12);
		carol.turnRight(30);
		carol.moveForward(7);
		carol.turnLeft(120);
		carol.moveForward(4);
		carol.mountRameses();
		carol.turnRight(90);
		carol.moveForward(6);
		carol.turnRight(90);
		carol.moveForward(18);
		carol.turnRight(90);
		carol.moveForward(5);
		carol.turnLeft(90);
		carol.moveForward(4);
		carol.turnLeft(90);
		carol.moveForward(36);
		carol.turnRight(90);
		carol.moveForward(3);
		carol.talkToRoy();
		carol.turnRight(180);
		carol.moveForward(3);
		carol.turnLeft(90);
		carol.moveForward(20);
		carol.turnLeft(10);
		carol.moveForward(30);
		carol.turnRight(90);
		carol.moveForward(10);
		carol.turnLeft(90);
		carol.moveForward(1);
		carol.turnRight(90);
		carol.moveForward(2);
		carol.turnRight(9);
		carol.moveForward(15);
		carol.turnLeft(90);
		carol.moveForward(10);
		carol.turnRight(90);
		carol.moveForward(29);
		carol.turnLeft(45);
		carol.moveForward(15);
		carol.turnRight(45);
		carol.moveForward(8);
		carol.turnLeft(90);
		carol.moveForward(28);
		carol.turnLeft(90);
		carol.moveForward(12);
		carol.turnRight(90);
		carol.moveForward(3);
		carol.turnLeft(90);
		carol.moveForward(8);
		carol.turnRight(90);
		carol.moveForward(1);
		carol.getAlertCarolinaCode();

		/// 7c79 is the AlertCarolinaCode

	}

}