package comp110;

/*
 * Author: Seth Little
 *
 * ONYEN: sethl
 *
 * UNC Honor Pledge: I certify that no unauthorized assistance has been 
 * received or given in the completion of this work. I collaborated with
 * no one other than official COMP110 UTAs on this code.
 */
public class UnlockCode {

	public static void main(String[] args) {

		AlertCarolinaButton button = new AlertCarolinaButton();
		button.setOnyen("sethl");
		button.setUnlockCode("7c79");

	}

}